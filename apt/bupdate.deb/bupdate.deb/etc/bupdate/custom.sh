# updater for snap
# delete this line if you don't have snap installed
snap refresh || echo -e "\033[1m\033[33mNo snap installed\nRun bupdate -e to edit custom commands\033[0m"

# updater for flatpak
# delete this line if you don't have snap flatpak
flatpak update || echo -e "\033[1m\033[33mNo flatpak installed\nRun bupdate -e to edit custom commands\033[0m"